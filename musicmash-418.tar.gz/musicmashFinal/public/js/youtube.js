
//Key za youtube
var youtube_apiKey='AIzaSyBzJZE_rk-xNPFJQKHxwLHj9GGEkXiTa9Q';

function searchYoutube(songName,youtubeSongsId){
    var q=songName;
    var request=gapi.client.youtube.search.list({
        q: q,
        part: 'snipet'
        });
    request.execute(function(respose) {
        var result=respose.result;
        if(result.items!=undefined)
        {
            youtubeSongsId.push(result.items[0]);
        }
    });
}
