$(document).ready(function(){
    $.ajaxSetup({
        async: false
    });
    
    var Genres = [];
    try{	
		//OBAVEZNO PRVO
		Genres = DownloadGenres(FmGenres,"",FmAPI);
	}
	catch(err)
	{
		
	}
	var genresHtml="";
	for(var i=0;i<Genres.length;i++)
	{
	    genresHtml+="<button class=\"btn btn-genre\">" + Genres[i].toLowerCase() + "</button>";
	}
	$("#genre-buttons").html(genresHtml);
	
	
	    $('.btn-genre').click(function(){
	    if(!$(this).hasClass('btn-checked'))
	    {
	        if(selectedGenres.length < 5)
	        {
	            $(this).addClass('btn-checked');
	            selectedGenres.push($(this).html());
	        }
	        
	    }
	    else
	    {
	        var novi = [];
	        for(var i = 0; i < selectedGenres.length; i++)
	        {
	            if(selectedGenres[i] != $(this).html())
	                novi.push(selectedGenres[i]);
	        }
	        selectedGenres = novi;
	        $(this).removeClass('btn-checked');
	    }
});

	
    var lista = MethodNothing(fbauthors);
    recommendedList = lista;
    updateLists();


$('#applyGenres').click(function(){
    
    if(selectedGenres.length != 0)
    {
        recommendedList = MethodGenre(fbauthors,selectedGenres);
        curentPlaying = 0;
        updateLists();
        changeUIPlaying();
    }
});


$('#shuffleList').click(function ()
{
    if(selectedGenres.length != 0)
    {
            recommendedList = MethodGenre(fbauthors,selectedGenres);
	        curentPlaying = 0;
	        updateLists();
	        changeUIPlaying();
    }
    else 
    {
        recommendedList = MethodNothing(fbauthors);
        curentPlaying = 0;
	    updateLists();
	    changeUIPlaying();
    }
    
});

$(".odvoji").fadeIn(2000).removeClass('applefancy');


});
/*
*/
//FM Global
var FmAPI = "&api_key=e80b96c29ff375da782a89c411715350&format=json";
var Geo = ["Albania",
"Andorra",
"Armenia",
"Austria",
"Azerbaijan",
"Belarus",
"Belgium",
"Bosnia and Herzegovina",
"Bulgaria",
"Croatia",
"Cyprus",
"Czech Republic",
"Denmark",
"Estonia",
"Finland",
"France",
"Georgia",
"Germany",
"Greece",
"Hungary",
"Iceland",
"Ireland",
"Italy",
"Kosovo",
"Latvia",
"Liechtenstein",
"Lithuania",
"Luxembourg",
"Macedonia",
"Malta",
"Moldova",
"Monaco",
"Montenegro",
"The Netherlands",
"Norway",
"Poland",
"Portugal",
"Romania",
"Russia",
"San Marino",
"Serbia",
"Slovakia",
"Slovenia",
"Spain",
"Sweden",
"Switzerland",
"Turkey",
"Ukraine",
"United Kingdom",
"Vatican City"];
//-----------------------------------------
//-----------------------------------------
//Get all genres
//Vrati sve zanrove
var FmGenres = "http://ws.audioscrobbler.com/2.0/?method=chart.gettoptags";

function DownloadGenres(link,additionalData,APIKEY)
{	
    var Genre = [];
	additionalData = "";
	var url = link+additionalData+APIKEY;
	$.getJSON(url,
	 function(data) {	
		try{
			var tmp = data.tags.tag;
			for(var i = 0 ; i < tmp.length ; i++)
			{		
				var title = tmp[i].name;
				Genre.push(title);
			}	
		}
		catch(err)
		{
			
		}		
	});	
	return Genre;
}

//-----------------------------------------
//-----------------------------------------
//Get top tracks by genre
//Vrati sve pesme naslusanije po zanru

var FmTopTracksFind = "http://ws.audioscrobbler.com/2.0/?method=tag.gettoptracks&tag=";

function DownloadTopTracksData(link,additionalData,APIKEY)
{
    var ALL_LASTFM_TOP_TRACKS_GENRE = [];
	var lastFmTracks = new LASTfmTracks();
	var url = link+additionalData+APIKEY;
	$.getJSON(url,
	 function(data) {	
		try{
			var tmp = data.tracks.track;
			for(var i = 0 ; i < tmp.length ; i++)
			{		
				var title = tmp[i].name;
				var artist = tmp[i].artist.name;
				var image_link = tmp[i].image[2]['#text'];
				var small_img = tmp[i].image[0]['#text'];			
				lastFmTracks.addTrack(new Track(title,artist,image_link,small_img));
			}		
			lastFmTracks.setGenre(additionalData);
			ALL_LASTFM_TOP_TRACKS_GENRE.push(lastFmTracks);
		}
		catch(err)
		{
			
		}
	});	
	return ALL_LASTFM_TOP_TRACKS_GENRE;
}
//-----------------------------------------
//-----------------------------------------
//Get top tracks from one artist
//Nadji top pesme od nekog izvodjaca

var FmTopTracksByArtist = "http://ws.audioscrobbler.com/2.0/?method=artist.gettoptracks&artist=";

function DownloadTopArtistsTracksData(link,additionalData,APIKEY)
{
    var ALL_LASTFM_TOP_ARTITS_TRACKS = [];
	var lastFmTracks = new LASTfmTracks();
	var url = link+additionalData+APIKEY;
	$.getJSON(url,
	 function(data) {
		try{		 
			var tmp = data.toptracks.track;
			for(var i = 0 ; i < tmp.length ; i++)
			{		
				var title = tmp[i].name;
				var artist = tmp[i].artist.name;
				var image_link = tmp[i].image[2]['#text'];
				var small_img = tmp[i].image[0]['#text'];
				lastFmTracks.addTrack(new Track(title,artist,image_link,small_img));
			}		
			lastFmTracks.setGenre(additionalData);
			ALL_LASTFM_TOP_ARTITS_TRACKS.push(lastFmTracks);
		}
		catch(err)
		{
			
		}
	});	
	return ALL_LASTFM_TOP_ARTITS_TRACKS;
}
//-----------------------------------------
//-----------------------------------------
//Get top tracks by geo location
//Vrati top pesme po geo lokaciji

var FmTopTracksGeo = "http://ws.audioscrobbler.com/2.0/?method=geo.gettoptracks&country=";

function DownloadGeoTracksData(link,additionalData,APIKEY)
{
	var lastFmTracks = new LASTfmTracks();
	var url = link+additionalData+APIKEY;
	var ALL_LASTFM_GEO_TRACKS = [];
	$.getJSON(url,
	 function(data) {
		try{
			var tmp = data.tracks.track;
			for(var i = 0 ; i < tmp.length ; i++)
			{		
				var title = tmp[i].name;
				var artist = tmp[i].artist.name;
				var image_link = tmp[i].image[2]['#text'];
				var small_img = tmp[i].image[0]['#text'];
				lastFmTracks.addTrack(new Track(title,artist,image_link,small_img));
			}		
			lastFmTracks.setGenre(additionalData);
			ALL_LASTFM_GEO_TRACKS.push(lastFmTracks);
		}
		catch(err)
		{
			
		}
	});	
	return ALL_LASTFM_GEO_TRACKS;
}
//-----------------------------------------
//-----------------------------------------
//Get top artists by geo location
//Vraca top izvodjace po geo lokaciji

var FmTopArtistsGeo = "http://ws.audioscrobbler.com/2.0/?method=geo.gettopartists&country=";

function DownloadGeoArtistsData(link,additionalData,APIKEY)
{
    var ALL_LASTFM_GEO_ARTISTS = [];
	var lastFmArtists = new LASTfmArtists();
	var url = link+additionalData+APIKEY;
	$.getJSON(url,
	 function(data) {	
		try{
			var tmp = data.topartists.artist;
			for(var i = 0 ; i < tmp.length ; i++)
			{		
				var name = tmp[i].name;
				var listeners = tmp[i].listeners;
				var image_link = tmp[i].image[2]['#text'];
				lastFmArtists.addArtist(new Artist(name,listeners,image_link));
			}				
			ALL_LASTFM_GEO_ARTISTS.push(lastFmArtists);
		}		
		catch(err)
		{
			
		}
	});	
	return ALL_LASTFM_GEO_ARTISTS;
}
//-----------------------------------------
//-----------------------------------------
//Get top WORLD tracks
//Vraca sve top pesme u SVETU

var FmTopWorldTracks = "http://ws.audioscrobbler.com/2.0/?method=chart.gettoptracks";


function DowloadWorldTopData(link,additionalData,APIKEY)
{
    var ALL_LASTFM_WORLD_TOP_TRACKS = [];
	var lastFmTracks = new LASTfmTracks();
	additionalData = "";
	var url = link+additionalData+APIKEY;
	$.getJSON(url,
	 function(data) {		
		try{
			var tmp = data.tracks.track;
			for(var i = 0 ; i < tmp.length ; i++)
			{		
				var title = tmp[i].name;
				var artist = tmp[i].artist.name;
				var image_link = tmp[i].image[2]['#text'];
				var small_img = tmp[i].image[0]['#text'];
				lastFmTracks.addTrack(new Track(title,artist,image_link,small_img));
			}		
			lastFmTracks.setGenre("top-world");
			ALL_LASTFM_WORLD_TOP_TRACKS.push(lastFmTracks);
		}
		catch(err)
		{
			
		}
	});	
	return ALL_LASTFM_WORLD_TOP_TRACKS;
}
//-----------------------------------------
//-----------------------------------------


//Artist Object
function Artist(p_name,p_listneres,p_imagelink)
{
	this.name = p_name;
	this.listneres = p_listneres;		
	this.image_link = p_imagelink;
}

//List of artists
function LASTfmArtists()
{
	this._artists = [];
	
	this.addArtist = function(artist)
	{
		if(artist === undefined)
		{
			alert("Artist is undefined!");
		}
		
		this._artists.push(artist);
	}
}
	
//Songs Object
function Track(p_title,p_artist,p_imagelink_large,p_image_small,p_mark)
{
	this.title = p_title;
	this.artist = p_artist;		
	this.image_link_large = p_imagelink_large;
	this.image_link_small = p_image_small;
	
	//heuristics
	if(p_mark === undefined)
	{
		this.mark = 8;
	}
	else
	{
		this.mark = p_mark;
	}
}

//List of objects in ALL_LASTFM_TRACKS
function LASTfmTracks()
{
	this._genre;
	this._tracks = [];
	
	this.setGenre = function(genre)
	{
		this._genre = genre;
	}
	
	this.addTrack = function(track)
	{
		if(track === undefined)
		{
			alert("Track is undefined!");
		}		
		this._tracks.push(track);
	}
}

/*

MAGIC. DO NOT TOUCH. RADIOACTIVE like Chernobly!
ASK 418.su for explanation!

   
*/


function shuffle(list) {
  var currentIndex = list.length, temporaryValue, randomIndex;

  // While there remain elements to shuffle...
  while (0 !== currentIndex) {

    // Pick a remaining element...
    randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex -= 1;

    // And swap it with the current element.
    temporaryValue = list[currentIndex];
    list[currentIndex] = list[randomIndex];
    list[randomIndex] = temporaryValue;
  }

  return list;
}

// Heuristika 1
// ALL_LASTFM_TOP_ARTITS_TRACKS
// ALL_LASTFM_WORLD_TOP_TRACKS
function MethodNothing(listaArtista)
{
	//Skracujemo listu artista na max 5
	var tmpListaArtista = shuffle(listaArtista);
	var trazeniArtisti = [];
	if(tmpListaArtista.length > 5)
	{
		for(var i = 0 ; i < 5 ; i++)
		{
			trazeniArtisti.push(tmpListaArtista[i]);
		}
	}

	//Ovde izvlacim sve top pesme
	var worldList = [];
	var ALL_LASTFM_WORLD_TOP_TRACKS = DowloadWorldTopData(FmTopWorldTracks,"",FmAPI);
	for(var i = 0 ; i < ALL_LASTFM_WORLD_TOP_TRACKS[0]._tracks.length ; i++)
	{
		worldList.push(ALL_LASTFM_WORLD_TOP_TRACKS[0]._tracks[i]);
	}
		
	//Prazna lista, samo stampamo TOP world tracks
	if(trazeniArtisti.length == 0)
	{		
		var shuffeled = shuffle(worldList);
		if(shuffeled.length > 10)
		{
			shuffeled = shuffeled.slice(0,10);
		}
		return shuffeled;
	}
	
	//Ovde izvlacimo sve top pesme za artiste koji su prosledjeni
	var listaSvihTrazenihArtista = [];
	for(var i = 0 ; i < trazeniArtisti.length ; i++)
	{
		//Ime parsiranje
		var name = trazeniArtisti[i].toLowerCase();
		name = name.replace(/ /g,"%20");
		//Preuzimanje podataka
		var ALL_LASTFM_TOP_ARTITS_TRACKS = DownloadTopArtistsTracksData(FmTopTracksByArtist,trazeniArtisti[i],FmAPI);
		if(ALL_LASTFM_TOP_ARTITS_TRACKS.length > 0)
		{
			for(var j = 0 ; j < ALL_LASTFM_TOP_ARTITS_TRACKS[0]._tracks.length ; j++) 
			{
				listaSvihTrazenihArtista.push(ALL_LASTFM_TOP_ARTITS_TRACKS[0]._tracks[j]);
				if(j > 10)
				{
					break;
				}
			}
		}		
	}	
	
	//Dobili smo:
	//WORLD top listu
	//Listu trazenih artista i njihovih najslusanijih pesama
	var RETURN_LIST = [];
	for(var i = 0 ; i < listaSvihTrazenihArtista.length ; i++)
	{
		for(var j = 0 ; j < worldList.length ; j++)
		{
			if(listaSvihTrazenihArtista[i].title.toLowerCase() === worldList[j].title.toLowerCase())
			{
				RETURN_LIST.push(listaSvihTrazenihArtista[i]);
			}
		}
	}
	
	//80 % trazenih
	if(RETURN_LIST.length == 0)
	{
		var artistShuffel = shuffle(listaSvihTrazenihArtista);
		for(var i = 0 ; i < 8 ; i++)
		{
			RETURN_LIST.push(artistShuffel[i])
		}
	}
	
	//20% top lists
	if(RETURN_LIST.length < 9)
	{
		for(var i = 0 ; i < 3 ; i++)
		{
			var item = worldList[Math.floor(Math.random()*worldList.length)];
			var postoji = false;
			for(var j = 0 ; j < RETURN_LIST.length ;j++)
			{
				if(item.title === RETURN_LIST[j].title)
				{
					postoji = true;
					break;
				}
			}
			if(!postoji)
			{
				RETURN_LIST.push(item);
			}
		}
	}
	
	var ret = shuffle(RETURN_LIST);
	return ret;
}

function MethodGenre(listaArtista,generes)
{
	var methodNothing = MethodNothing(listaArtista);
	
	//Ovde dobijamo listu zanrova
	var listaPesamaPoZanru = [];
	for(var i = 0 ; i < generes.length ; i++)
	{
		var gen = encodeURI(generes[i]);//genres[i].replace(/\s/g,"%20");
		var ALL_LASTFM_TOP_TRACKS_GENRE = DownloadTopTracksData(FmTopTracksFind,gen,FmAPI);
		if(ALL_LASTFM_TOP_TRACKS_GENRE.length > 0)
		{
			for(var j = 0 ; j < ALL_LASTFM_TOP_TRACKS_GENRE[0]._tracks.length ; j++) 
			{
				listaPesamaPoZanru.push(ALL_LASTFM_TOP_TRACKS_GENRE[0]._tracks[j]);
			}
		}
	}
	
	var ret = [];
	//Matchujemo pesme koje je lajkovao na fb-u sa pesmama po znaru
	for(var i = 0 ; i < methodNothing.length ; i++)
	{
		for(var j = 0 ; j < listaPesamaPoZanru.length ; j++)
		{
			if(methodNothing[i].title === listaPesamaPoZanru[j].title && 
			methodNothing[i].artist === listaPesamaPoZanru[j].title)
			{
				ret.push(methodNothing[i]);
			}
		}
	}
	
	if(ret.length == 0)
	{
		var listaShuffel = shuffle(listaPesamaPoZanru);
		for(var i = 0 ; i < 10 ; i++)
		{
			ret.push(listaShuffel[i])
		}
	}
	
	if(ret.length < 8)
	{
		for(var i = 0 ; i < 3 ; i++)
		{
			var item = listaPesamaPoZanru[Math.floor(Math.random()*listaPesamaPoZanru.length)];
			var postoji = false;
			for(var j = 0 ; j < ret.length ;j++)
			{
				if(item.title === ret[j].title)
				{
					postoji = true;
					break;
				}
			}
			if(!postoji)
			{
				ret.push(item);
			}
		}
	}
	
	var returendData = shuffle(ret);
	return returendData;
}
function tplawesome(e,t){res=e;for(var n=0;n<t.length;n++){res=res.replace(/\{\{(.*?)\}\}/g,function(e,r){return t[n][r]})}return res}
var clicked=false;
/*
var list=new Array();

function generateYoutubeList(songList){
    var counter=0;
    for(i=0;i<songList.length;i++)
    {
        var request=gapi.client.youtube.search.list({
            part: "snippet",
            type: "video",
            q: encodeURIComponent(songList[i].artist+" "+songList[i].title).replace(/%20/g, "+"),
            maxResults: 1,
            categoryId: 10 //Music
        });
        request.execute(function(response) {
            var results = response.result;
            list.push(results.items[0].id.videoId);
            if(counter==songList.length)
            {
                
            }
            else
                counter++;
        });
    }
}*/

function playNewSong(song) {
    var request=gapi.client.youtube.search.list({
            part: "snippet",
            type: "video",
            q: decodeURIComponent(song.artist+" "+song.title).replace(/%20/g, "+"),
            maxResults: 1,
            categoryId: 10 //Music
        });
        request.execute(function(response) {
            player.loadVideoById(response.items[0].id.videoId);
            
        });
}

function init() {
    gapi.client.setApiKey("AIzaSyAnpMIzjO9iBZcP9noEWyIfiofSIzrf7zg");
    gapi.client.load("youtube", "v3", function() {
        // yt api is ready
    });
}

var curentPlaying=0;
var player;


    var tag = document.createElement('script');

    tag.src = "https://www.youtube.com/iframe_api";
    var firstScriptTag = document.getElementsByTagName('script')[0];
    firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);

//Funkcija se poziva kad se loaduje iframe za player
function onYouTubeIframeAPIReady(){
    player = new YT.Player('player', {
            height: '0',
            width: '0',
            events: {
                'onReady': onPlayerReady,
                'onStateChange': onPlayerStateChange
            }
        });
}

function onPlayerReady(event) {
    changeUIUpdate();
}

function onPlayerStateChange(event)
{
    if(event.data==YT.PlayerState.PLAYING)
    {
        changeUIPlaying();
        changeUIUpdate();
        updateLists();
    }
    else if(event.data==YT.PlayerState.PAUSED)
    {
        changeUIPaused();
    }
    else if(event.data==YT.PlayerState.ENDED)
    {
        curentPlaying++;
        if(curentPlaying>=recommendedList.length)
        {
            player.stopVideo();
            curentPlaying=recommendedList.length-1;
            if(selectedGenres.length!=0)
            {
                
                recommendedList = MethodGenre(fbauthors,selectedGenres);
    	        curentPlaying = 0;
    	        updateLists();
    	        changeUIPlaying();
            }
            else
            {
                vrecommendedList = MethodNothing(fbauthors);
                curentPlaying = 0;
	            updateLists();
	            changeUIPlaying();
            }
            playNewSong(recommendedList[curentPlaying]);
        }
        else
        {
            playNewSong(recommendedList[curentPlaying]);
        }
    }
}

//------------------------------------------------------------

$(document).ready(function(){
    
    $("#button-back").click(function(){
        curentPlaying--;
        if(curentPlaying<0)
            curentPlaying=0;
        playNewSong(recommendedList[curentPlaying]);
    });
    
    $("#button-play").click(function(){
        
        if(recommendedList.length<1)
            return;
        if(player.getPlayerState()==-1)//Unstarted
        {
            playNewSong(recommendedList[curentPlaying]);
        }
        else if(player.getPlayerState()==YT.PlayerState.PAUSED)
        {
            player.playVideo()
        }
        else if(player.getPlayerState()==YT.PlayerState.PLAYING)
        {
            player.pauseVideo();
        }
        else
            playNewSong(recommendedList[curentPlaying]);
    });

    $("#button-next").click(function(){
        curentPlaying++;
        if(curentPlaying>=recommendedList.length)
        {
            if(selectedGenres.length!=0)
            {
                
                recommendedList = MethodGenre(fbauthors,selectedGenres);
    	        curentPlaying = 0;
    	        updateLists();
    	        changeUIPlaying();
            }
            else
            {
                recommendedList = MethodNothing(fbauthors);
                curentPlaying = 0;
                updateLists();
                changeUIPlaying();
            }
            playNewSong(recommendedList[curentPlaying]);
        }
        playNewSong(recommendedList[curentPlaying]);
    });
    
     $("#button-mute").click(function(){
        if(player.isMute())
         {
             player.unMute();
             changeUIMuted(false)
         }
        else
        {
             player.mute();
             changeUIMuted(true)
        }
    });
    
    
});


//------------------------------------------------------------
//------------------------------------------------------------

function changeUIPlaying(){
   $("#button-play").html("<img src=\"../pause-circular-button.png\" height=\"50\" width=\"50\">");
}

function changeUINotStarted(){
    
}

function changeUIPaused(){
    $("#button-play").html("<img src=\"../play-button.png\" height=\"50\" width=\"50\">");
}

function changeUIMuted(mute)
{
    if(mute)
        $("#button-mute").html();
    else
        $("#button-mute").html();
}

function changeUIUpdate(){
    $(".song #picture").html('<img src="' + recommendedList[curentPlaying].image_link_large + '">');
    $(".song #author").html(recommendedList[curentPlaying].artist);
    $(".song #track").html(recommendedList[curentPlaying].title);
}

var toplist=new Array();
function updateLists()
{
    var listHtml="";
    
    for(var i=0;i<recommendedList.length;i++)
    {
        var current = '';
        var buttn = 'play-button.png';
        if(i == curentPlaying)
        {
            current = ' current ';
            buttn = 'bars.png';
        }
            
            
        listHtml+="<li class='playlist-item " + current + "  '>"+
                   "<div class=\"picture\"><img width=\"48\" height=\"48\" src=\""+recommendedList[i].image_link_small+"\"></div>"+
                   "<div class=\"playlist-song\">"+
                       "<span class=\"author playlist-author\">"+recommendedList[i].artist+"</span><br>"+
                       "<span class=\"track playlist-track\">"+recommendedList[i].title+"</span>"+
                   "</div><div class=\"play-song\"><img src=\"../" + buttn + "\" height=\"50\" width=\"50\" onclick='hackPlayer(" + i + ")'></div></li>";
    }
    $("#topList").html(listHtml);
}
function hackPlayer(index)
{
    playNewSong(recommendedList[index]);
    curentPlaying = index;
    changeUIUpdate();
    updateLists();
}
function removeFromTopList(){
    
    updateLists();
}

function addToTopList()
{
    updateLists();
}
    
    
//# sourceMappingURL=all.js.map
