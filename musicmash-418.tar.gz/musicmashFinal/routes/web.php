<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
|   POST    -> CREATE
|   GET     -> READ
|   PUT     -> UPDATE
|   DELETE  -> DELETE
*/

Route::get('/', function () {
    return view('home');
});

//Auth::routes();

Route::get('auth/login/facebook', 'AuthController@redirectToProvider');
Route::get('auth/callback/facebook', 'AuthController@handleProviderCallback');
Route::get('auth/logout/facebook', 'AuthController@logout');

Route::get('/play', 'HomeController@play');

Route::get('privacy2', function(){
    echo "We don't keep any data on our platform.";
});

Route::group(['prefix' => 'admin', 'middleware' => ['role:admin']], function(){
    Route::get('/special','HomeController@special');
});