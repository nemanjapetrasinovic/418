$(document).ready(function(){
    $.ajaxSetup({
        async: false
    });
    
    var Genres = [];
    try{	
		//OBAVEZNO PRVO
		Genres = DownloadGenres(FmGenres,"",FmAPI);
	}
	catch(err)
	{
		
	}
	var genresHtml="";
	for(var i=0;i<Genres.length;i++)
	{
	    genresHtml+="<button class=\"btn btn-genre\">" + Genres[i].toLowerCase() + "</button>";
	}
	$("#genre-buttons").html(genresHtml);
	
	
	    $('.btn-genre').click(function(){
	    if(!$(this).hasClass('btn-checked'))
	    {
	        if(selectedGenres.length < 5)
	        {
	            $(this).addClass('btn-checked');
	            selectedGenres.push($(this).html());
	        }
	        
	    }
	    else
	    {
	        var novi = [];
	        for(var i = 0; i < selectedGenres.length; i++)
	        {
	            if(selectedGenres[i] != $(this).html())
	                novi.push(selectedGenres[i]);
	        }
	        selectedGenres = novi;
	        $(this).removeClass('btn-checked');
	    }
});

	
    var lista = MethodNothing(fbauthors);
    recommendedList = lista;
    updateLists();


$('#applyGenres').click(function(){
    
    if(selectedGenres.length != 0)
    {
        recommendedList = MethodGenre(fbauthors,selectedGenres);
        curentPlaying = 0;
        updateLists();
        changeUIPlaying();
    }
});


$('#shuffleList').click(function ()
{
    if(selectedGenres.length != 0)
    {
            recommendedList = MethodGenre(fbauthors,selectedGenres);
	        curentPlaying = 0;
	        updateLists();
	        changeUIPlaying();
    }
    else 
    {
        recommendedList = MethodNothing(fbauthors);
        curentPlaying = 0;
	    updateLists();
	    changeUIPlaying();
    }
    
});

$(".odvoji").fadeIn(2000).removeClass('applefancy');


});
/*
*/