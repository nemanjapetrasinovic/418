
var toplist=new Array();
function updateLists()
{
    var listHtml="";
    
    for(var i=0;i<recommendedList.length;i++)
    {
        var current = '';
        var buttn = 'play-button.png';
        if(i == curentPlaying)
        {
            current = ' current ';
            buttn = 'bars.png';
        }
            
            
        listHtml+="<li class='playlist-item " + current + "  '>"+
                   "<div class=\"picture\"><img width=\"48\" height=\"48\" src=\""+recommendedList[i].image_link_small+"\"></div>"+
                   "<div class=\"playlist-song\">"+
                       "<span class=\"author playlist-author\">"+recommendedList[i].artist+"</span><br>"+
                       "<span class=\"track playlist-track\">"+recommendedList[i].title+"</span>"+
                   "</div><div class=\"play-song\"><img src=\"../" + buttn + "\" height=\"50\" width=\"50\" onclick='hackPlayer(" + i + ")'></div></li>";
    }
    $("#topList").html(listHtml);
}
function hackPlayer(index)
{
    playNewSong(recommendedList[index]);
    curentPlaying = index;
    changeUIUpdate();
    updateLists();
}
function removeFromTopList(){
    
    updateLists();
}

function addToTopList()
{
    updateLists();
}
    
    