/*

MAGIC. DO NOT TOUCH. RADIOACTIVE like Chernobly!
ASK 418.su for explanation!

   
*/


function shuffle(list) {
  var currentIndex = list.length, temporaryValue, randomIndex;

  // While there remain elements to shuffle...
  while (0 !== currentIndex) {

    // Pick a remaining element...
    randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex -= 1;

    // And swap it with the current element.
    temporaryValue = list[currentIndex];
    list[currentIndex] = list[randomIndex];
    list[randomIndex] = temporaryValue;
  }

  return list;
}

// Heuristika 1
// ALL_LASTFM_TOP_ARTITS_TRACKS
// ALL_LASTFM_WORLD_TOP_TRACKS
function MethodNothing(listaArtista)
{
	//Skracujemo listu artista na max 5
	var tmpListaArtista = shuffle(listaArtista);
	var trazeniArtisti = [];
	if(tmpListaArtista.length > 5)
	{
		for(var i = 0 ; i < 5 ; i++)
		{
			trazeniArtisti.push(tmpListaArtista[i]);
		}
	}

	//Ovde izvlacim sve top pesme
	var worldList = [];
	var ALL_LASTFM_WORLD_TOP_TRACKS = DowloadWorldTopData(FmTopWorldTracks,"",FmAPI);
	for(var i = 0 ; i < ALL_LASTFM_WORLD_TOP_TRACKS[0]._tracks.length ; i++)
	{
		worldList.push(ALL_LASTFM_WORLD_TOP_TRACKS[0]._tracks[i]);
	}
		
	//Prazna lista, samo stampamo TOP world tracks
	if(trazeniArtisti.length == 0)
	{		
		var shuffeled = shuffle(worldList);
		if(shuffeled.length > 10)
		{
			shuffeled = shuffeled.slice(0,10);
		}
		return shuffeled;
	}
	
	//Ovde izvlacimo sve top pesme za artiste koji su prosledjeni
	var listaSvihTrazenihArtista = [];
	for(var i = 0 ; i < trazeniArtisti.length ; i++)
	{
		//Ime parsiranje
		var name = trazeniArtisti[i].toLowerCase();
		name = name.replace(/ /g,"%20");
		//Preuzimanje podataka
		var ALL_LASTFM_TOP_ARTITS_TRACKS = DownloadTopArtistsTracksData(FmTopTracksByArtist,trazeniArtisti[i],FmAPI);
		if(ALL_LASTFM_TOP_ARTITS_TRACKS.length > 0)
		{
			for(var j = 0 ; j < ALL_LASTFM_TOP_ARTITS_TRACKS[0]._tracks.length ; j++) 
			{
				listaSvihTrazenihArtista.push(ALL_LASTFM_TOP_ARTITS_TRACKS[0]._tracks[j]);
				if(j > 10)
				{
					break;
				}
			}
		}		
	}	
	
	//Dobili smo:
	//WORLD top listu
	//Listu trazenih artista i njihovih najslusanijih pesama
	var RETURN_LIST = [];
	for(var i = 0 ; i < listaSvihTrazenihArtista.length ; i++)
	{
		for(var j = 0 ; j < worldList.length ; j++)
		{
			if(listaSvihTrazenihArtista[i].title.toLowerCase() === worldList[j].title.toLowerCase())
			{
				RETURN_LIST.push(listaSvihTrazenihArtista[i]);
			}
		}
	}
	
	//80 % trazenih
	if(RETURN_LIST.length == 0)
	{
		var artistShuffel = shuffle(listaSvihTrazenihArtista);
		for(var i = 0 ; i < 8 ; i++)
		{
			RETURN_LIST.push(artistShuffel[i])
		}
	}
	
	//20% top lists
	if(RETURN_LIST.length < 9)
	{
		for(var i = 0 ; i < 3 ; i++)
		{
			var item = worldList[Math.floor(Math.random()*worldList.length)];
			var postoji = false;
			for(var j = 0 ; j < RETURN_LIST.length ;j++)
			{
				if(item.title === RETURN_LIST[j].title)
				{
					postoji = true;
					break;
				}
			}
			if(!postoji)
			{
				RETURN_LIST.push(item);
			}
		}
	}
	
	var ret = shuffle(RETURN_LIST);
	return ret;
}

function MethodGenre(listaArtista,generes)
{
	var methodNothing = MethodNothing(listaArtista);
	
	//Ovde dobijamo listu zanrova
	var listaPesamaPoZanru = [];
	for(var i = 0 ; i < generes.length ; i++)
	{
		var gen = encodeURI(generes[i]);//genres[i].replace(/\s/g,"%20");
		var ALL_LASTFM_TOP_TRACKS_GENRE = DownloadTopTracksData(FmTopTracksFind,gen,FmAPI);
		if(ALL_LASTFM_TOP_TRACKS_GENRE.length > 0)
		{
			for(var j = 0 ; j < ALL_LASTFM_TOP_TRACKS_GENRE[0]._tracks.length ; j++) 
			{
				listaPesamaPoZanru.push(ALL_LASTFM_TOP_TRACKS_GENRE[0]._tracks[j]);
			}
		}
	}
	
	var ret = [];
	//Matchujemo pesme koje je lajkovao na fb-u sa pesmama po znaru
	for(var i = 0 ; i < methodNothing.length ; i++)
	{
		for(var j = 0 ; j < listaPesamaPoZanru.length ; j++)
		{
			if(methodNothing[i].title === listaPesamaPoZanru[j].title && 
			methodNothing[i].artist === listaPesamaPoZanru[j].title)
			{
				ret.push(methodNothing[i]);
			}
		}
	}
	
	if(ret.length == 0)
	{
		var listaShuffel = shuffle(listaPesamaPoZanru);
		for(var i = 0 ; i < 10 ; i++)
		{
			ret.push(listaShuffel[i])
		}
	}
	
	if(ret.length < 8)
	{
		for(var i = 0 ; i < 3 ; i++)
		{
			var item = listaPesamaPoZanru[Math.floor(Math.random()*listaPesamaPoZanru.length)];
			var postoji = false;
			for(var j = 0 ; j < ret.length ;j++)
			{
				if(item.title === ret[j].title)
				{
					postoji = true;
					break;
				}
			}
			if(!postoji)
			{
				ret.push(item);
			}
		}
	}
	
	var returendData = shuffle(ret);
	return returendData;
}