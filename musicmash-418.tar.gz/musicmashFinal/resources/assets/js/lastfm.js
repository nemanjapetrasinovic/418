//FM Global
var FmAPI = "&api_key=e80b96c29ff375da782a89c411715350&format=json";
var Geo = ["Albania",
"Andorra",
"Armenia",
"Austria",
"Azerbaijan",
"Belarus",
"Belgium",
"Bosnia and Herzegovina",
"Bulgaria",
"Croatia",
"Cyprus",
"Czech Republic",
"Denmark",
"Estonia",
"Finland",
"France",
"Georgia",
"Germany",
"Greece",
"Hungary",
"Iceland",
"Ireland",
"Italy",
"Kosovo",
"Latvia",
"Liechtenstein",
"Lithuania",
"Luxembourg",
"Macedonia",
"Malta",
"Moldova",
"Monaco",
"Montenegro",
"The Netherlands",
"Norway",
"Poland",
"Portugal",
"Romania",
"Russia",
"San Marino",
"Serbia",
"Slovakia",
"Slovenia",
"Spain",
"Sweden",
"Switzerland",
"Turkey",
"Ukraine",
"United Kingdom",
"Vatican City"];
//-----------------------------------------
//-----------------------------------------
//Get all genres
//Vrati sve zanrove
var FmGenres = "http://ws.audioscrobbler.com/2.0/?method=chart.gettoptags";

function DownloadGenres(link,additionalData,APIKEY)
{	
    var Genre = [];
	additionalData = "";
	var url = link+additionalData+APIKEY;
	$.getJSON(url,
	 function(data) {	
		try{
			var tmp = data.tags.tag;
			for(var i = 0 ; i < tmp.length ; i++)
			{		
				var title = tmp[i].name;
				Genre.push(title);
			}	
		}
		catch(err)
		{
			
		}		
	});	
	return Genre;
}

//-----------------------------------------
//-----------------------------------------
//Get top tracks by genre
//Vrati sve pesme naslusanije po zanru

var FmTopTracksFind = "http://ws.audioscrobbler.com/2.0/?method=tag.gettoptracks&tag=";

function DownloadTopTracksData(link,additionalData,APIKEY)
{
    var ALL_LASTFM_TOP_TRACKS_GENRE = [];
	var lastFmTracks = new LASTfmTracks();
	var url = link+additionalData+APIKEY;
	$.getJSON(url,
	 function(data) {	
		try{
			var tmp = data.tracks.track;
			for(var i = 0 ; i < tmp.length ; i++)
			{		
				var title = tmp[i].name;
				var artist = tmp[i].artist.name;
				var image_link = tmp[i].image[2]['#text'];
				var small_img = tmp[i].image[0]['#text'];			
				lastFmTracks.addTrack(new Track(title,artist,image_link,small_img));
			}		
			lastFmTracks.setGenre(additionalData);
			ALL_LASTFM_TOP_TRACKS_GENRE.push(lastFmTracks);
		}
		catch(err)
		{
			
		}
	});	
	return ALL_LASTFM_TOP_TRACKS_GENRE;
}
//-----------------------------------------
//-----------------------------------------
//Get top tracks from one artist
//Nadji top pesme od nekog izvodjaca

var FmTopTracksByArtist = "http://ws.audioscrobbler.com/2.0/?method=artist.gettoptracks&artist=";

function DownloadTopArtistsTracksData(link,additionalData,APIKEY)
{
    var ALL_LASTFM_TOP_ARTITS_TRACKS = [];
	var lastFmTracks = new LASTfmTracks();
	var url = link+additionalData+APIKEY;
	$.getJSON(url,
	 function(data) {
		try{		 
			var tmp = data.toptracks.track;
			for(var i = 0 ; i < tmp.length ; i++)
			{		
				var title = tmp[i].name;
				var artist = tmp[i].artist.name;
				var image_link = tmp[i].image[2]['#text'];
				var small_img = tmp[i].image[0]['#text'];
				lastFmTracks.addTrack(new Track(title,artist,image_link,small_img));
			}		
			lastFmTracks.setGenre(additionalData);
			ALL_LASTFM_TOP_ARTITS_TRACKS.push(lastFmTracks);
		}
		catch(err)
		{
			
		}
	});	
	return ALL_LASTFM_TOP_ARTITS_TRACKS;
}
//-----------------------------------------
//-----------------------------------------
//Get top tracks by geo location
//Vrati top pesme po geo lokaciji

var FmTopTracksGeo = "http://ws.audioscrobbler.com/2.0/?method=geo.gettoptracks&country=";

function DownloadGeoTracksData(link,additionalData,APIKEY)
{
	var lastFmTracks = new LASTfmTracks();
	var url = link+additionalData+APIKEY;
	var ALL_LASTFM_GEO_TRACKS = [];
	$.getJSON(url,
	 function(data) {
		try{
			var tmp = data.tracks.track;
			for(var i = 0 ; i < tmp.length ; i++)
			{		
				var title = tmp[i].name;
				var artist = tmp[i].artist.name;
				var image_link = tmp[i].image[2]['#text'];
				var small_img = tmp[i].image[0]['#text'];
				lastFmTracks.addTrack(new Track(title,artist,image_link,small_img));
			}		
			lastFmTracks.setGenre(additionalData);
			ALL_LASTFM_GEO_TRACKS.push(lastFmTracks);
		}
		catch(err)
		{
			
		}
	});	
	return ALL_LASTFM_GEO_TRACKS;
}
//-----------------------------------------
//-----------------------------------------
//Get top artists by geo location
//Vraca top izvodjace po geo lokaciji

var FmTopArtistsGeo = "http://ws.audioscrobbler.com/2.0/?method=geo.gettopartists&country=";

function DownloadGeoArtistsData(link,additionalData,APIKEY)
{
    var ALL_LASTFM_GEO_ARTISTS = [];
	var lastFmArtists = new LASTfmArtists();
	var url = link+additionalData+APIKEY;
	$.getJSON(url,
	 function(data) {	
		try{
			var tmp = data.topartists.artist;
			for(var i = 0 ; i < tmp.length ; i++)
			{		
				var name = tmp[i].name;
				var listeners = tmp[i].listeners;
				var image_link = tmp[i].image[2]['#text'];
				lastFmArtists.addArtist(new Artist(name,listeners,image_link));
			}				
			ALL_LASTFM_GEO_ARTISTS.push(lastFmArtists);
		}		
		catch(err)
		{
			
		}
	});	
	return ALL_LASTFM_GEO_ARTISTS;
}
//-----------------------------------------
//-----------------------------------------
//Get top WORLD tracks
//Vraca sve top pesme u SVETU

var FmTopWorldTracks = "http://ws.audioscrobbler.com/2.0/?method=chart.gettoptracks";


function DowloadWorldTopData(link,additionalData,APIKEY)
{
    var ALL_LASTFM_WORLD_TOP_TRACKS = [];
	var lastFmTracks = new LASTfmTracks();
	additionalData = "";
	var url = link+additionalData+APIKEY;
	$.getJSON(url,
	 function(data) {		
		try{
			var tmp = data.tracks.track;
			for(var i = 0 ; i < tmp.length ; i++)
			{		
				var title = tmp[i].name;
				var artist = tmp[i].artist.name;
				var image_link = tmp[i].image[2]['#text'];
				var small_img = tmp[i].image[0]['#text'];
				lastFmTracks.addTrack(new Track(title,artist,image_link,small_img));
			}		
			lastFmTracks.setGenre("top-world");
			ALL_LASTFM_WORLD_TOP_TRACKS.push(lastFmTracks);
		}
		catch(err)
		{
			
		}
	});	
	return ALL_LASTFM_WORLD_TOP_TRACKS;
}
//-----------------------------------------
//-----------------------------------------


//Artist Object
function Artist(p_name,p_listneres,p_imagelink)
{
	this.name = p_name;
	this.listneres = p_listneres;		
	this.image_link = p_imagelink;
}

//List of artists
function LASTfmArtists()
{
	this._artists = [];
	
	this.addArtist = function(artist)
	{
		if(artist === undefined)
		{
			alert("Artist is undefined!");
		}
		
		this._artists.push(artist);
	}
}
	
//Songs Object
function Track(p_title,p_artist,p_imagelink_large,p_image_small,p_mark)
{
	this.title = p_title;
	this.artist = p_artist;		
	this.image_link_large = p_imagelink_large;
	this.image_link_small = p_image_small;
	
	//heuristics
	if(p_mark === undefined)
	{
		this.mark = 8;
	}
	else
	{
		this.mark = p_mark;
	}
}

//List of objects in ALL_LASTFM_TRACKS
function LASTfmTracks()
{
	this._genre;
	this._tracks = [];
	
	this.setGenre = function(genre)
	{
		this._genre = genre;
	}
	
	this.addTrack = function(track)
	{
		if(track === undefined)
		{
			alert("Track is undefined!");
		}		
		this._tracks.push(track);
	}
}
