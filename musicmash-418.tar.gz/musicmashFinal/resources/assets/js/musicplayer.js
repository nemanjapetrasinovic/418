function tplawesome(e,t){res=e;for(var n=0;n<t.length;n++){res=res.replace(/\{\{(.*?)\}\}/g,function(e,r){return t[n][r]})}return res}
var clicked=false;
/*
var list=new Array();

function generateYoutubeList(songList){
    var counter=0;
    for(i=0;i<songList.length;i++)
    {
        var request=gapi.client.youtube.search.list({
            part: "snippet",
            type: "video",
            q: encodeURIComponent(songList[i].artist+" "+songList[i].title).replace(/%20/g, "+"),
            maxResults: 1,
            categoryId: 10 //Music
        });
        request.execute(function(response) {
            var results = response.result;
            list.push(results.items[0].id.videoId);
            if(counter==songList.length)
            {
                
            }
            else
                counter++;
        });
    }
}*/

function playNewSong(song) {
    var request=gapi.client.youtube.search.list({
            part: "snippet",
            type: "video",
            q: decodeURIComponent(song.artist+" "+song.title).replace(/%20/g, "+"),
            maxResults: 1,
            categoryId: 10 //Music
        });
        request.execute(function(response) {
            player.loadVideoById(response.items[0].id.videoId);
            
        });
}

function init() {
    gapi.client.setApiKey("AIzaSyAnpMIzjO9iBZcP9noEWyIfiofSIzrf7zg");
    gapi.client.load("youtube", "v3", function() {
        // yt api is ready
    });
}

var curentPlaying=0;
var player;


    var tag = document.createElement('script');

    tag.src = "https://www.youtube.com/iframe_api";
    var firstScriptTag = document.getElementsByTagName('script')[0];
    firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);

//Funkcija se poziva kad se loaduje iframe za player
function onYouTubeIframeAPIReady(){
    player = new YT.Player('player', {
            height: '0',
            width: '0',
            events: {
                'onReady': onPlayerReady,
                'onStateChange': onPlayerStateChange
            }
        });
}

function onPlayerReady(event) {
    changeUIUpdate();
}

function onPlayerStateChange(event)
{
    if(event.data==YT.PlayerState.PLAYING)
    {
        changeUIPlaying();
        changeUIUpdate();
        updateLists();
    }
    else if(event.data==YT.PlayerState.PAUSED)
    {
        changeUIPaused();
    }
    else if(event.data==YT.PlayerState.ENDED)
    {
        curentPlaying++;
        if(curentPlaying>=recommendedList.length)
        {
            player.stopVideo();
            curentPlaying=recommendedList.length-1;
            if(selectedGenres.length!=0)
            {
                
                recommendedList = MethodGenre(fbauthors,selectedGenres);
    	        curentPlaying = 0;
    	        updateLists();
    	        changeUIPlaying();
            }
            else
            {
                vrecommendedList = MethodNothing(fbauthors);
                curentPlaying = 0;
	            updateLists();
	            changeUIPlaying();
            }
            playNewSong(recommendedList[curentPlaying]);
        }
        else
        {
            playNewSong(recommendedList[curentPlaying]);
        }
    }
}

//------------------------------------------------------------

$(document).ready(function(){
    
    $("#button-back").click(function(){
        curentPlaying--;
        if(curentPlaying<0)
            curentPlaying=0;
        playNewSong(recommendedList[curentPlaying]);
    });
    
    $("#button-play").click(function(){
        
        if(recommendedList.length<1)
            return;
        if(player.getPlayerState()==-1)//Unstarted
        {
            playNewSong(recommendedList[curentPlaying]);
        }
        else if(player.getPlayerState()==YT.PlayerState.PAUSED)
        {
            player.playVideo()
        }
        else if(player.getPlayerState()==YT.PlayerState.PLAYING)
        {
            player.pauseVideo();
        }
        else
            playNewSong(recommendedList[curentPlaying]);
    });

    $("#button-next").click(function(){
        curentPlaying++;
        if(curentPlaying>=recommendedList.length)
        {
            if(selectedGenres.length!=0)
            {
                
                recommendedList = MethodGenre(fbauthors,selectedGenres);
    	        curentPlaying = 0;
    	        updateLists();
    	        changeUIPlaying();
            }
            else
            {
                recommendedList = MethodNothing(fbauthors);
                curentPlaying = 0;
                updateLists();
                changeUIPlaying();
            }
            playNewSong(recommendedList[curentPlaying]);
        }
        playNewSong(recommendedList[curentPlaying]);
    });
    
     $("#button-mute").click(function(){
        if(player.isMute())
         {
             player.unMute();
             changeUIMuted(false)
         }
        else
        {
             player.mute();
             changeUIMuted(true)
        }
    });
    
    
});


//------------------------------------------------------------
//------------------------------------------------------------

function changeUIPlaying(){
   $("#button-play").html("<img src=\"../pause-circular-button.png\" height=\"50\" width=\"50\">");
}

function changeUINotStarted(){
    
}

function changeUIPaused(){
    $("#button-play").html("<img src=\"../play-button.png\" height=\"50\" width=\"50\">");
}

function changeUIMuted(mute)
{
    if(mute)
        $("#button-mute").html();
    else
        $("#button-mute").html();
}

function changeUIUpdate(){
    $(".song #picture").html('<img src="' + recommendedList[curentPlaying].image_link_large + '">');
    $(".song #author").html(recommendedList[curentPlaying].artist);
    $(".song #track").html(recommendedList[curentPlaying].title);
}