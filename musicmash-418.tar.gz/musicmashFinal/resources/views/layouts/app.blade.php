<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- Styles -->
    <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link href="/css/app.css" rel="stylesheet">
    <link href="//gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">
    <link rel="stylesheet" href="./css/oblurlay.min.css">
       <!-- Scripts -->
    <script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
        ]); ?>
    </script>
</head>
<body>
    <div id="app">
        <!--<div class="container">
            <div class="row">
                @if(Session::has('toast'))
                <div class="alert alert-success">
                  {{ Session::get('toast') }}
                </div>
                @endif
            </div>
        </div>-->
        <!-- Modal -->
        <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
          <div class="container">
            <div class="row">
              <div class="col-sm-6 col-sm-offset-3 text-center">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">×</button>
                <br><br>
                <h1>Log in with your facebook account</h1>
                <form>
                    <div class="form-group">
                      <label for="email">Email:</label>
                      <input type="email" class="form-control" id="email" placeholder="Enter email">
                    </div>
                    <div class="form-group">
                      <label for="pwd">Password:</label>
                      <input type="password" class="form-control" id="pwd" placeholder="Enter password">
                    </div>
                    <button type="submit" class="btn btn-default">Login</button>
                    <hr>
                <div class="alert alert-danger"><h4>{{ Session::get('toast') }}</h4></div>
              </div>
            </div>
          </div>
        </div>
        
        <div class="container" id="wrap" style="background:url('background.jpg')" height:500px>
            @yield('content')
        </div>
        
        
    </div>

    <!-- Scripts -->
    
    <script
			  src="//code.jquery.com/jquery-3.1.1.min.js"
			  integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8="
			  crossorigin="anonymous"></script>
        <script src="//gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>
        <script src="/js/all.js"></script>
        <script src="https://apis.google.com/js/client.js?onload=init"></script>
 
</body>
</html>
