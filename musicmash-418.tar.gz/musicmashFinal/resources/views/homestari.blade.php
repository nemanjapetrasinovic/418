@extends('layouts.app')

@section('content')

    <div class="row">
         <div class="col-md-4">
            <div class="container">
                <div class="row">
                    <div class="col-md-4 ">
                        <div class="panel panel-default">
                        <div class="panel-body" >
                            <ul class="nav nav-pills nav-stacked">
                              <li role="presentation" class="btn-moj"><a href="#"><i class="fa fa-user-circle-o" aria-hidden="true"></i>
Profile</a></li>
                              <li role="presentation" class="btn-moj"><a href="#">Profile</a></li>
                              <li role="presentation" class="btn-moj"><a href="#">Profile</a></li>
                              <li role="presentation" class="btn-moj"><a href="#">Profile</a></li>
                              <li role="presentation" class="btn-moj"><a href="#">Profile</a></li>
                            </ul>
                        </div>
                        <div class="panel-body">
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
        <div class="col-md-8">
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                        <div class="panel panel-default">
                            <div class="panel-heading">Add new post</div>
            
                            <div class="panel-body">
                                <form method="post" action="post/create">
                                     {{ csrf_field() }}
                                    <input type="textarea" class="form-control" style="min-width: 100%" name="text"/>
                                    <p></p>
                                        <label class="radio-inline">
                                          <input type="radio" name="optradio">
                                              <span class="label label-primary">Blue</span>
                                        </label>
                                        <label class="radio-inline">
                                          <input type="radio" name="optradio">
                                              <span class="label label-success">Green</span>
                                        </label>
                                        <label class="radio-inline">
                                          <input type="radio" name="optradio">
                                              <span class="label label-danger">Red</span>
                                        </label>
                                        <label class="radio-inline">
                                          <input type="radio" name="optradio">
                                              <span class="label label-warning">Yellow</span>
                                        </label>
                                         
                                </form>
                                <!-- Button trigger modal -->
                                        <button class="btn btn-primary" data-toggle="modal" data-target="#myModal" style="float:right">
                                          Submit
                                        </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div class="panel panel-default">
                        <div class="panel-body" >
                        </div>
                        <div class="panel-body">
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-8">
                </div>
            </div>
        </div>

    </div>
</div>
@endsection