@extends('layouts.app')

@section('content')

<div class="container">
    <h1 class="tittle">MusicMash</h1>
            <h1 class="subtittle">Find your perfect match music!</h1>
            <div class="container center">
                <div class="center">
                <a href='/auth/login/facebook' class="btn btn-block btn-social btn-facebook btn-lg"
                style="text-align:center">
                    <span class="fa fa-facebook"></span>Sign in with Facebook
                    </a>  
                    </br>
                <a href="http://418.su/play"><p  style="text-align:center">Proceed without Facebook...</p></a>
                </div>
            </div>
</div>
@endsection