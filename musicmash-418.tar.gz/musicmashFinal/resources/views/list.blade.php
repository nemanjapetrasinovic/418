@extends('layouts.app')

@section('content')
<div class="container odvoji applefancy">
    <div class="row">
        <div class="col-md-4">
            <div class=" player-side">
            <h1>MusicMash</h1>
            <div class="song">
                <div class="picture" id="picture">
                     <img src="../slika.png">               
                </div>
                <span class="author" id="author">Author</span><br/>
                <span class="track" id="track">Song name</span>
            </div>
                <ul class="player-controls">
                    <li id="button-back"><img src="../previous-track-button.png" height="50" width="50"></li>
                    <li id="button-play"><img src="../play-button.png" height="50" width="50"></li>
                    <li id="button-next"><img src="../next-track-button.png" height="50" width="50"></li>
                </ul>
                @if(!empty($token))
                    <a href="http://418.su/auth/logout/facebook" class="btn big-blue gray">Logout</a>
                @endif
            </div>
            <div class=" player-side">
                <h2>Genre</h2>
                <div id="genre-buttons">
                    <input type="button" class="btn btn-genre" value="Pop">
                    <input type="button" class="btn btn-genre" value="Jazz">
                    <input type="button" class="btn btn-genre" value="Classic Rock">
                </div>
                <button type="button" id="applyGenres" class="btn big-blue">Apply genres</button>
            </div>
        </div>
        <div class="col-md-8">
            <h2>Based on your taste</h2>
            <div class="underline">
                
            </div>
           <ul class="playlist" id="topList">
               <li class="playlist-item">
                   <div class="picture"><img width="48" height="48" src="../slika.png"></div>
                   <div class="playlist-song">
                       <span class="author playlist-author">Author</span><br>
                       <span class="track playlist-track">Song name</span>
                   </div>
                   <div class="play-song"><img src="../play-button.png" height="50" width="50"></div>
               </li>
               <li class="playlist-item">
                   <div class="picture"><img width="48" height="48" src="../slika.png"></div>
                   <div class="playlist-song">
                       <span class="author playlist-author">Author</span><br>
                       <span class="track playlist-track">Song name</span>
                   </div>
                   <div class="play-song"><img src="../play-button.png" height="50" width="50"></div>
               </li><li class="playlist-item">
                   <div class="picture"><img width="48" height="48" src="../slika.png"></div>
                   <div class="playlist-song">
                       <span class="author playlist-author">Author</span><br>
                       <span class="track playlist-track">Song name</span>
                   </div>
                   <div class="play-song"><img src="../play-button.png" height="50" width="50"></div>
               </li>
               <li class="playlist-item">
                   <div class="picture"><img width="48" height="48" src="../slika.png"></div>
                   <div class="playlist-song">
                       <span class="author playlist-author">Author</span><br>
                       <span class="track playlist-track">Song name</span>
                   </div>
                   <div class="play-song"><img src="../play-button.png" height="50" width="50"></div>
               </li>
               <li class="playlist-item">
                   <div class="picture"><img width="48" height="48" src="../slika.png"></div>
                   <div class="playlist-song">
                       <span class="author playlist-author">Author</span><br>
                       <span class="track playlist-track">Song name</span>
                   </div>
                   <div class="play-song"><img src="../play-button.png" height="50" width="50"></div>
               </li>

           </ul>
               <div align="center"><button type="button" id="shuffleList" class="btn big-blue">Shuffle It!</button></div>
        </div>
    </div>
</div>
<script>
    @if($javascript)
        {!! $javascript !!}
    @endif    
    var recommendedList = [];
   var  selectedGenres = [];
</script>

@endsection
<div id="player"></div>