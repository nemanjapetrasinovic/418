<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Auth;
use App\User;
use App\Project;

class UserController extends Controller
{
    //
    public function createProject(Request $request)
    {
        $project=new Project;
        $project->name=$request->name;
        $project->description=$request->description;
        $project->user_id=Auth::user()->id;
        $project->save();
    }
    
    public function getProject(Request $request, User $user){
        return Project::where('id',$user->id)->get();
    }
    
    public function addWorker(Request $request){
        $worker=new Worker;
        
    }
}
