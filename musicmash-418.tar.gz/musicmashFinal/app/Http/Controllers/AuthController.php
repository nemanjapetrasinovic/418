<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Socialite;
use Facebook\Facebook;
use Session;
use Guzzle;

class AuthController extends Controller
{
      /**
     * Redirect the user to the GitHub authentication page.
     *
     * @return Response
     */
    public function redirectToProvider()
    {
        return Socialite::driver('facebook')->fields(array('user_likes','user_posts'))->scopes(['user_likes','user_posts','user_actions.video','user_actions.music'])->redirect();
    }

    /**
     * Obtain the user information from GitHub.
     *
     * @return Response
     */
    public function handleProviderCallback(Request $request)
    {
        if(!empty($request->input('error')))
        {
            return redirect('/');
        }
        try
        {
            $user = Socialite::driver('facebook')->user();
            session()->put('fb_user_access_token', $user->token);
            if(isset($user->error))
                throw "error";
            return redirect('play');    
        }
        catch (Exception $e) {
            //dd($e->response);
            echo $e;
            exit;
        }
    }
    public function logout()
    {
        $token = session('fb_user_access_token');
        if(!empty($token))
        {
            Guzzle::delete('https://graph.facebook.com/v2.5/me/permissions?access_token=' . $token);
            session()->put('fb_user_access_token',''); //remove socket
        }
           
            
        //TODO: FLASH SUCESS MSG
        return  redirect('/');
    }
}
