<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Facebook\Facebook;
use Session;
use Guzzle;
class HomeController extends Controller
{
    public function play()
    {
        $authors = [];
         $token = session('fb_user_access_token');
         //echo $token;
         if(!empty($token))
         {//LOGOVAN
             $response = Guzzle::get('https://graph.facebook.com/v2.5/me/music?access_token=' . $token);
             $data = json_decode($response->getBody());
    		$more = false;
    		 if(isset($data->paging->next))
    			 $more = true;
    		foreach($data->data as $item)
            {
                array_push($authors,$item->name);
            }
    		while($more)
    		{
    			
    			$response = Guzzle::get($data->paging->next);
    			$data = json_decode($response->getBody());
    			foreach($data->data as $item)
                 {
                     array_push($authors,strtolower(urlencode($item->name)));
                 }
    			if(!isset($data->paging->next))
    			  $more = false;			
    		}
             //$authors = [];
         }
        
         $fbauthors = json_encode($authors);
         $javascript = "var fbauthors = " . $fbauthors . ';';
         /*
         $response = Guzzle::get('https://graph.facebook.com/v2.5/me/feed?access_token=' . $token);
         $data = json_decode($response->getBody());
         foreach($data->data as $item)
         {
             if(isset($item->message))
             {
                 if()
             }
         }*/
         //echo $javascript;
         
         return view('list',compact('javascript','token'));
    }
}
