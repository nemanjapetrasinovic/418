<?php echo $__env->make('console::partials.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div id="console" class="console" data-action="<?php echo e(route('console_execute')); ?>">
	<ul id="response" class="response">
	</ul>

	<nav id="controlbar" class="controlbar">
		<ul id="controls" class="controls">
		</ul>
		<div id="execute" class="execute">Execute</div>
	</nav>

	<section id="editor" class="editor"></section>
</div>

<?php echo $__env->make('console::partials.templates', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('console::partials.foot', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
