		<script src="<?php echo e(asset('vendor/console/js/vendor/jquery.js')); ?>"></script>
		<script src="<?php echo e(asset('vendor/console/js/vendor/plugins.js')); ?>"></script>
		<script src="<?php echo e(asset('vendor/console/js/vendor/codemirror.js')); ?>"></script>
		<script src="<?php echo e(asset('vendor/console/js/main.js')); ?>"></script>
	</body>
</html>
