<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Add new post</div>

                <div class="panel-body">
                    <form method="post" action="post/create">
                         <?php echo e(csrf_field()); ?>

                        <input type="textarea" class="form-control" style="min-width: 100%" name="text"/>
                        <p></p>
                            <label class="radio-inline">
                              <input type="radio" name="optradio">
                                  <span class="label label-primary">Blue</span>
                            </label>
                            <label class="radio-inline">
                              <input type="radio" name="optradio">
                                  <span class="label label-success">Green</span>
                            </label>
                            <label class="radio-inline">
                              <input type="radio" name="optradio">
                                  <span class="label label-danger">Red</span>
                            </label>
                            <label class="radio-inline">
                              <input type="radio" name="optradio">
                                  <span class="label label-warning">Yellow</span>
                            </label>
                        <input type="submit" class="btn btn-primary" style="float:right" value="Submit"/>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container">
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-body" >
                    <?php echo e($post->user->name); ?>

                </div>
                <div class="panel-body">
                        <?php echo e($post->text); ?>

                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <?php echo e($posts->links()); ?>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>