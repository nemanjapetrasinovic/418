<?php $__env->startSection('content'); ?>

<div class="container">
    <h1 class="tittle">MusicMash</h1>
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <h1 align="center" style="padding-top:100px">Find your perfect match music!</h1>
            <div class="container">
                <div class="row">
                    <div class="col-md-4 col-md-offset-2" style="padding-top:200px">
                            <a href='/auth/login/facebook' class="btn btn-block btn-social btn-facebook btn-lg">
                                <span class="fa fa-facebook"></span>Sign in with Facebook
                            </a>  
                            </br>
                            <a href="http://www.w3schools.com" calss="col-md-4">don't have facebook</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>