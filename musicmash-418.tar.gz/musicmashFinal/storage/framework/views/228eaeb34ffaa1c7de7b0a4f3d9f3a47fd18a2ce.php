<?php $__env->startSection('imissyouhome'); ?>

<div class="container">
    <div class="row">
        <p>ksadjlsjdalskdjalsk</p>
    </div>
</div>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>