#MusicMash
Smart music player that knows what you like. The app was built in 24 hour on a Hackathon challange organized by SICEF Nis Serbia.

##418 team members
Nikola Vitanovic - nikola@vitanovic.net
Nemanja Petrovic - nemanjapetrovic1794@gmail.com
Stefan Stamenovic - stefan.stamenovic@gmail.com
Nemanja Petrasinovic - nemanjapet94@gmail.com

##Live App
http://418.su/
